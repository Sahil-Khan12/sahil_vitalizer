//
//  ClientSideTests.swift
//  ClientSideTests
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//

import Testing

struct ClientSideTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
