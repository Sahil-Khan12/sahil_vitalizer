//
//  ClientSideApp.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//

import SwiftUI

@main
struct ClientSideApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
