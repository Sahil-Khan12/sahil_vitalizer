//
//  ContentView.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        RouterView {
            LoginView()
        }
    }
}

#Preview {
    ContentView()
}
