//
//  HomeViewModel.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//
import SwiftUI

class HeaderViewModel: ObservableObject {
    @Published var header: HeaderModel = HeaderModel(
        logoUrl: "https://picsum.photos/200/100"
    )
}
