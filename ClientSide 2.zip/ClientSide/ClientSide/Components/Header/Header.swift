//
//  Header.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//
import SwiftUI

struct Header: View {
    @StateObject var headerViewModelInstance = HeaderViewModel()
    var body: some View {
        VStack {
            HStack {
                AsyncImage(url: URL(string: headerViewModelInstance.header.logoUrl)) { phase in
                    if let image = phase.image {
                        image
                            .resizable()
                            .scaledToFit()
                            .frame(height: 50)
                    }
                }
                .padding()
                Spacer()
                Image(systemName: "cart.fill")
                    .font(Font.system(size: 25))
                Image(systemName: "person.crop.circle.fill")
                    .font(Font.system(size: 25))
                    .padding(.trailing, 10)
            }
        }
        Divider()
    }
}

struct Headline: View {
    @ObservedObject var headerViewModelInstance: HeaderViewModel
    var body: some View {
        HStack {
            Text("\(headerViewModelInstance.header.headlineText)")
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 5)
        .background(Color(red: 0/255, green: 0/255, blue: 0/255))
        .frame(maxWidth: .infinity)
    }
}

#Preview {
    Header()
}
