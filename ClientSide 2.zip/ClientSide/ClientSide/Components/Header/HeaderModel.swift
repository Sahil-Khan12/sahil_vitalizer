//
//  HomeModel.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//

import SwiftUI

struct HeaderModel: Codable {
    var headlineText: String = ""
    var logoUrl: String = ""
}
