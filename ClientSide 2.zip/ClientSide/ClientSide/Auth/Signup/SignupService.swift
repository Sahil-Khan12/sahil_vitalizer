import Foundation

struct SignUpRequest: Codable {
    let userName: String
    let email: String
    let password: String
    var companyName: String = "DeltaX"
}

struct SignUpResponse: Codable {
    let message: String
}

class SignUpAuthService {
    static let shared = SignUpAuthService()
    private let baseURL = "https://172.16.50.40:8000/api"

    func signUp(username: String, email: String, password: String) async throws {
        let url = URL(string: "\(baseURL)/auth/Register")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body = SignUpRequest(userName: username, email: email, password: password)
        request.httpBody = try JSONEncoder().encode(body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw URLError(.badServerResponse)
        }
        
        let result = try JSONDecoder().decode(SignUpResponse.self, from: data)
        print(result.message)
    }
}
