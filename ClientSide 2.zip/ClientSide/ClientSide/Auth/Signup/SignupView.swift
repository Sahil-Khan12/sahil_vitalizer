import SwiftUI

struct SignUpView: View {
    @State private var username = ""
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage: String? = nil
    @State private var isLoading = false
    
    @EnvironmentObject var router: Router
    
    var body: some View {
        Spacer()
        VStack {
            Text("Sign Up")
                .font(.largeTitle)
                .padding()

            TextField("Username", text: $username)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .padding(.bottom, 10)

            TextField("Email", text: $email)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .padding(.bottom, 10)

            SecureField("Password", text: $password)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .padding(.bottom, 20)

            if let errorMessage = errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding(.bottom, 10)
            }

            Button(action: {
                signUp()
            }) {
                Text(isLoading ? "Signing up..." : "Sign Up")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(ColorVars.primary[0])
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
        .padding()
        Spacer()
    }

    private func signUp() {
        guard !username.isEmpty, !email.isEmpty, !password.isEmpty else {
            errorMessage = "All fields are required."
            return
        }

        if !isValidEmail(email) {
            errorMessage = "Please enter a valid email address."
            return
        }

        Task {
            do {
                isLoading = true
                errorMessage = nil
                try await SignUpAuthService.shared.signUp(username: username, email: email, password: password)
                print("Sign-up successful")
                router.clearPath()
                router.navigateTo(.home)
            } catch {
                print("Sign-up failed with error: \(error)")
                errorMessage = "Sign-up failed. Please try again."
            }
        }
    }

    private func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailTest.evaluate(with: email)
    }
}

#Preview {
    SignUpView()
}
