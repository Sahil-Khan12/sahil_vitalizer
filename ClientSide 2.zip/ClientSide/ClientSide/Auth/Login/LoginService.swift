//
//  LoginService.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//
import SwiftUI

struct LoginRequest: Codable {
    let email: String
    let password: String
}

struct LoginResponse: Codable {
    let token: String 
}

class AuthService {
    static let shared = AuthService()
    private let baseURL = "https://yourapi.com"

    func login(email: String, password: String) async throws {
        let url = URL(string: "\(baseURL)/login")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body = LoginRequest(email: email, password: password)
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw URLError(.badServerResponse)
        }

        let result = try JSONDecoder().decode(LoginResponse.self, from: data)

        UserDefaults.standard.set(result.token, forKey: "authToken")
    }
}
