import SwiftUI

struct LoginView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage: String? = nil
    @State private var isLoading = false
    
    @EnvironmentObject var router: Router

    var body: some View {
        VStack {
            Spacer()
            Text("Log in")
                .font(.largeTitle)
                .padding()

            TextField("Email", text: $email)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .padding(.bottom, 10)

            SecureField("Password", text: $password)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .padding(.bottom, 20)

            if let errorMessage = errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding(.bottom, 10)
            }

            Button(action: {
                login()
            }) {
                Text(isLoading ? "Logging in..." : "Login")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(ColorVars.primary[0])
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            
            Button("Don't have an account? Sign up here") {
                router.navigateTo(.signUp)
            }
            .foregroundColor(.blue)
            .padding(.top, 20)

            Spacer()
        }
        .padding()
    }

    private func login() {
        guard !email.isEmpty, !password.isEmpty else {
            errorMessage = "Email and password cannot be empty."
            return
        }

        if !isValidEmail(email) {
            errorMessage = "Please enter a valid email address."
            return
        }

        Task {
            do {
                isLoading = true
                errorMessage = nil
                try await AuthService.shared.login(email: email, password: password)
                print("Login successful")
            } catch {
                errorMessage = "Login failed. Please check your credentials."
            }
        }
    }

    private func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailTest.evaluate(with: email)
    }
}

#Preview {
    LoginView()
}
