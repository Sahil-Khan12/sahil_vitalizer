//
//  Home.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//
import SwiftUI

struct Home: View {
    @StateObject var homeViewModelInstance = HomeViewModel()
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            Header()
            ImageSlider(homeViewModelInstance: homeViewModelInstance)
                .padding(.vertical, 10)
            ProductList()
            ProductList()
            Spacer()
        }
    }
}

#Preview {
    Home()
}
