//
//  ProductViewModel.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//
import SwiftUI

class ProductViewModel: ObservableObject {
    @Published var product: ProductModel = ProductModel (
        productName: "XYZ",
        price: 100,
        Discount: 40,
        rating: 3,
        imageUrls: "https://picsum.photos/200/200",
        isLiked: false
    )
}
