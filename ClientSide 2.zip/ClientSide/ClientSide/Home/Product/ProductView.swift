//
//  ProductView.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//
import SwiftUI

struct ProductView: View {
    @StateObject var productViewModelInstance = ProductViewModel()
    
    var body: some View {
        VStack(alignment: .leading) {
            ZStack(alignment: .top) {
                // Correcting the color range
                Color(red: 247 / 255, green: 247 / 255, blue: 254 / 255)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                
                VStack {
                    HStack {
                        Text("-\(productViewModelInstance.product.Discount)%")
                            .frame(width: 60, height: 30)
                            .background(Color.yellow)
                            .cornerRadius(5)
                        Spacer()
                        ZStack {
                            Circle()
                                .foregroundStyle(.white)
                                .frame(width: 30, height: 30)
                            Image(systemName: "suit.heart.fill")
                                .foregroundStyle(productViewModelInstance.product.isLiked ? .red : .gray)
                                .onTapGesture {
                                    productViewModelInstance.product.isLiked.toggle()
                                }
                        }
                        
                    }
                    .padding()
                    
                    // Fixing the AsyncImage with a URL
                    AsyncImage(url: URL(string: productViewModelInstance.product.imageUrls)) { phase in
                        if let image = phase.image {
                            image
                                .resizable()
                                .scaledToFit()
                                .frame(width: 150, height: 150)
                        } else {
                            ProgressView()
                        }
                    }
                }
            }
            .frame(width: 250, height: 250) // Adjusted height to fit the content
            VStack (alignment: .leading, spacing: 10) {
                Text(productViewModelInstance.product.productName)
                    .fontWeight(.semibold)
                Text("$\(productViewModelInstance.product.price)")
                HStack {
                    ForEach(1...5, id: \.self) { i in
                        Image(systemName: "star.fill")
                            .foregroundColor(productViewModelInstance.product.rating >= i ? .yellow : .gray)
                    }
                }
            }
            .padding(.leading, 15)
            .padding(.top,5)
                            
        }
    }
}

#Preview {
    ProductView()
}
