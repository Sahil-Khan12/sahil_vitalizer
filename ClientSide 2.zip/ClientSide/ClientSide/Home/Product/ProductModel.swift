//
//  ProductModel.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//
import SwiftUI

struct ProductModel: Codable, Identifiable, Hashable {
    var id: UUID = UUID()
    var productName: String = ""
    var price: Int = 0
    var Discount: Int = 0
    var rating: Int = 1
    var imageUrls: String = ""
    var isLiked: Bool = false
}
