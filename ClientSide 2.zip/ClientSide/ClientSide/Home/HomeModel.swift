////
////  HomeModel.swift
////  ClientSide
////
////  Created by Kamakshi Bhardwaj on 26/03/25.
////
//
import SwiftUI

struct HomeModel: Codable {
    var sliderImages: [String] = [
        "https://picsum.photos/200/200",
        "https://picsum.photos/200/200",
        "https://picsum.photos/200/200",
        "https://picsum.photos/200/200"
    ]
    
}
