////
////  HomeViewModel.swift
////  ClientSide
////
////  Created by Kamakshi Bhardwaj on 26/03/25.
////
import SwiftUI

class HomeViewModel: ObservableObject {
    @Published var home: HomeModel = HomeModel(sliderImages: [
        "https://picsum.photos/200/200",
        "https://picsum.photos/200/200",
        "https://picsum.photos/200/200",
        "https://picsum.photos/200/200",
        "https://picsum.photos/200/200"
    ])
}
