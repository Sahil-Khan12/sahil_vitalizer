//
//  ImageSlider.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//
import SwiftUI

struct ImageSlider: View {
    // Array of image names or URLs for the slider
    
    @ObservedObject var homeViewModelInstance: HomeViewModel
    
    // To keep track of the current index of the image being displayed
    @State private var currentIndex = 0
    
    var body: some View {
        VStack {
            // Image Slider using TabView
            TabView(selection: $currentIndex) {
                ForEach(0..<homeViewModelInstance.home.sliderImages.count, id: \.self) { index in
                    AsyncImage(url: URL(string: homeViewModelInstance.home.sliderImages[index])) { phase in
                        if let image = phase.image {
                            image
                                .resizable()
                                .scaledToFill()
                                .frame(width: 350, height: 200)
                                .cornerRadius(10)
                        } else {
                            ProgressView()
                        }
                    }
                    .tag(index) // Tag each image with its index
                }
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .automatic)) // Page-style slider
            .frame(height: 200)
        }
        .cornerRadius(10)
    }
}
