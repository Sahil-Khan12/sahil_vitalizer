//
//  ProductListViewModel.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//
import SwiftUI

class ProductListViewModel: ObservableObject {
    @Published var product: ProductListModel = ProductListModel(
        productList: [ProductView(), ProductView(), ProductView()],
        categoryName: "Some Category",
        productListTitle: "Some Title"
    )
}
