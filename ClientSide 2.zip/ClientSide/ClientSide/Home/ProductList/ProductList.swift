//
//  ProductList.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//

import SwiftUI

struct ProductList: View {
    @StateObject var productListViewModelInstance = ProductListViewModel()
    var body: some View {
        VStack(alignment: .leading) {
                HStack {
                    RoundedRectangle(cornerSize: CGSize(width: 5, height: 5))
                        .frame(width: 10, height: 30)
                        .foregroundStyle(.yellow)
                        .padding(.trailing, 5)
                    Text(productListViewModelInstance.product.categoryName)
                }
                .padding()
                
            Text(productListViewModelInstance.product.productListTitle)
                .font(.system(size: 24))
                .fontWeight(.semibold)
                .padding(.leading)

                
                HStack {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(productListViewModelInstance.product.productList.indices, id: \.self) { index in
                                productListViewModelInstance.product.productList[index] // Display each ProductView
                                    .padding()
                            }
                        }
                    }
                }
        }
    }
}

#Preview {
    ProductList()
}
