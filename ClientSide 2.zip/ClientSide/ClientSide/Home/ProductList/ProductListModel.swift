//
//  ProductListModel.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//

import SwiftUI

struct ProductListModel {
    var productList: [ProductView] = []
    var categoryName: String = ""
    var productListTitle: String = ""
}
