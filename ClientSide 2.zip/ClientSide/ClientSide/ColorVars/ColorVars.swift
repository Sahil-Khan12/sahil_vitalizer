//
//  ColorVars.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//
import SwiftUI

class ColorVars {
    static var headlineBg: String = "black"
    static var primary: [Color] = [.black, .yellow, Color(red: 254/255, green: 42/255, blue: 42/255)]
    static var secondary: [Color] = [.black, .yellow, Color(red: 254/255, green: 42/255, blue: 42/255)]
    static var tertiary: [Color] = [.black, .yellow, Color(red: 254/255, green: 42/255, blue: 42/255)]
}
