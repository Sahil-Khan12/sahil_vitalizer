//
//  Routing.swift
//  ClientSide
//
//  Created by Kamakshi Bhardwaj on 26/03/25.
//
//

//  RouterView.swift
//  Routing
//
//  Created by Tanmay Patil on 20/02/25.
//
import SwiftUI

struct RouterView<Content: View>: View {
    @StateObject var router: Router = Router()
    private let content: Content
    
    init(content: () -> Content) {
        self.content = content()
    }
    
    var body: some View {
        NavigationStack(path: $router.path) {
            content
                .navigationDestination(for: Router.Route.self) { route in
                    router.view(for: route)
                }
        }
        .environmentObject(router)
    }
}

class Router: ObservableObject {
    @Published var path: NavigationPath = NavigationPath()
    
    enum Route: Hashable {
        case signUp
        case logIn
        case home
    }
    
    func view(for route: Route) -> some View {
        Group {
            switch route {
            case .signUp:
                SignUpView()
            case .logIn:
                LoginView()
            case .home:
                Home()
            }
        }
    }
    
    func navigateTo(_ appRoute: Route) {
        path.append(appRoute)
    }
    
    func goBack() {
        if !path.isEmpty {
            path.removeLast()
        }
    }
    
    func clearPath() {
        path.removeLast(path.count)
    }

}

//struct ViewA: View {
//    @EnvironmentObject var router: Router
//    
//    var body: some View {
//        VStack {
//            Button("Go to ViewB") {
//                router.navigateTo(.viewB)
//            }
//            Button("Go to ViewC") {
//                router.navigateTo(.viewC("Got from A"))
//            }
//        }
//        Text("View A")
//    }
//}
//
//struct ViewB: View {
//    @EnvironmentObject var router: Router
//    
//    var body: some View {
//        VStack {
//            Button("Go to ViewA") {
//                router.navigateTo(.viewA)
//            }
//            Button("Go to ViewC") {
//                router.navigateTo(.viewC("Got from B"))
//            }
//        }
//        Text("View B")
//    }
//}
//
//struct ViewC: View {
//    @EnvironmentObject var router: Router
//    var text: String
//    
//    var body: some View {
//        VStack {
//            Button("Go to ViewA") {
//                router.navigateTo(.viewA)
//            }
//            Button("Go to ViewB") {
//                router.navigateTo(.viewB)
//            }
//        }
//        Text("View C")
//    }
//}

#Preview {
    RouterView {
        LoginView()
    }
}






